<?php 
require 'connection.php';

$sql="DELETE FROM `product` WHERE product_id=".$_GET['product_id'];
$result=$con->query($sql);
header("location:danhsach.php");
$con->close();
?>