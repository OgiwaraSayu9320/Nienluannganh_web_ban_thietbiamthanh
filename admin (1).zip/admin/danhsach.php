<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Danh sách sản phẩm</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="danhsach.php">
	<link rel="stylesheet" type="text/css" href="table.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body class="body1">
	<?php
	session_start();

	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
			<hr>
			<ul>
				<li>
					<a href="index.php">Thêm hàng hóa</a>
				</li>

				<li class="menu-item">
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>
				<li>
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>
				
				<li>
					<a href="doanhthu.php">Doanh thu</a>
				</li>
				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>
				<li>
				<a href="logoutadmin.php"><i class="fas fa-sign-out"></i> Đăng xuất</a>
				</li>


				<?php
				require 'connection.php';
				$sql = "select * from admin where admin_id='$admin_id'";
				$result = $con->query($sql);
				while ($row = $result->fetch_assoc()) {
				?>
					<li><a href="#"><i class="fas fa-user"> </i> <?= $row['admin_name'] ?></a>
					</li>

				<?php
				}


				?>

			</ul>
		</div>

		<div class="content">
			<div class="danhsach">
				<?php
				require 'connection.php';
				$sql = "SELECT * FROM `product`";
				$result = $con->query($sql);
				?>

				<table class="table table-triped table-hover">
					<thead>
						<tr>
							
								<th>ID Sản phẩm</th>
								<th>Tên sản phẩm</th>
								<th>Giá sản phẩm</th>
								<th>Kiểu</th>
								<th>Hình ảnh</th>
								
								<th>Sửa</th>
								<th>Xóa</th>

						</tr>

					</thead>

					<?php
					while ($row = $result->fetch_assoc()) {
						echo "<tr>	
			<td>" . $row['product_id'] . "</td>
			<td>" . $row['product_name'] . "</td>
			<td>" . $row['product_price'] . "</td>
			<td>" . $row['product_type'] . "</td>
			
			<td style='text-align: center'><img src='" . $row['product_image'] . "' height=50px width=50px></td>

			<td><a href='phpsuasp.php?product_id=" . $row['product_id'] . "'><i class='fas fa-edit' style='color:black'></i></a></td>
			<td><a href='phpxoasp.php?product_id=" . $row['product_id'] . "'><i class='fas fa-trash' style='color:black'></i></a></td>


			

</tr>";
					}

					?>
				</table>


			</div>

		</div>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
</body>

</html>