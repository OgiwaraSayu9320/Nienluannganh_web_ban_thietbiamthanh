<?php
require 'connection.php';
$product_id=$_POST['product_id'];
$product_name=$_POST['product_name'];
$product_quanlity=$_POST['product_quanlity'];
$product_sold=$_POST['product_sold'];
$product_discription=$_POST['product_discription'];

$image2="./image/".$_FILES['product_image2']['name'];
$sql="INSERT INTO `product_detail`(`product_id`, `product_name`, `product_image2`, `product_quantity`, `product_description`, `product_sold`) VALUES ('$product_id','$product_name','$image2','$product_quanlity','$product_discription','$product_sold') ";
move_uploaded_file($_FILES['product_image2']['tmp_name'], $image2);
$result=$con->query($sql);

 header("location: danhsach.php");
$con->close();



?>