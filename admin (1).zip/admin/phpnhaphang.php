<?php
session_start();
require 'connection.php';
$admin_id=$_SESSION['admin_id'];
$giam=$_POST['giam'];
$product_id=$_POST['product_id'];
if(isset($_SESSION['admin_id'])){
	$quantity_add=$_POST['quantity_add'];
	$sql="UPDATE `product` SET `product_quantity`= product_quantity + '$quantity_add' WHERE product_id='$product_id'";
	$result=$con->query($sql);


	$sql1="UPDATE `product` SET `giam`= '$giam',`product_price`= giagiam - giagiam*('$giam'/100) WHERE product_id='$product_id'";
	$result=$con->query($sql1);


	
	 header("location:nhaphang.php");
}
else{
		header("location:loginadmin.html");
};


?>