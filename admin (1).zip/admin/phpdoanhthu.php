<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Doanh thu</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="table.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body>
	<?php
	session_start();

	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
			<hr>
			<ul>
				<li>
					<a href="index.php">Thêm hàng hóa</a>
				</li>

				<li>
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>
				<li>
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>
				<li>
					<a href="chitiethoadon.php">Chi tiết hóa đơn</a>
				</li>
				<li class="menu-item">
					<a href="doanhthu.php">Doanh thu</a>
				</li>
				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>
				<li>
					<a href="logoutadmin.php"><i class="fas fa-sign-out"></i> Đăng xuất</a>
				</li>

				<?php
				require 'connection.php';
				$sql = "select * from admin where admin_id='$admin_id'";
				$result = $con->query($sql);
				while ($row = $result->fetch_assoc()) {
				?>
					<li><a href="#"><i class="fas fa-user"> </i> <?= $row['admin_name'] ?></a>
					</li>

				<?php
				}
				$con->close();

				?>

			</ul>
		</div>
		<div class="content">
		<?php
		$tungay = $_POST['tungay'];

		$denngay = $_POST['denngay'];
		?>

		<form action="phpdoanhthu.php" method="POST">
			<div class="lich">
				Từ ngày <input type="date" name="tungay" value="<?php echo "$tungay" ?>">
				Đến ngày <input type="date" name="denngay" value="<?php echo "$denngay" ?>">
				<input type="submit" value="Chọn" name="">
			</div>

		</form>

		<table class="table table-triped table-hover">
			<thead>
				<tr>
					<th>Tên khách hàng</th>
					<th>Tổng hóa đơn</th>
					<th>Ngày mua hàng</th>
					<th>Địa chỉ</th>
				</tr>
			</thead>

			<?php
			require 'connection.php';
			$sql1 = "UPDATE `turnover` SET `total`=(SELECT SUM(bill_total) FROM bill1 WHERE bill_date BETWEEN '$tungay' AND '$denngay') WHERE 1";
			$result = $con->query($sql1);

			$sql = "SELECT * FROM `bill1` WHERE bill_date BETWEEN '$tungay' and '$denngay'";
			$result = $con->query($sql);
			while ($row = $result->fetch_assoc()) {
			?>
				<tr>
					<td><?= $row['customer_name'] ?></td>
					<td><?= number_format($row['bill_total']) ?>đ</td>
					<td><?= $row['bill_date'] ?></td>
					<td><?= $row['bill_adress'] ?></td>
				</tr>
			<?php } ?>
		</table>
		<?php
		$sql2 = "SELECT DISTINCT `total` FROM `turnover` WHERE 1";
		$result = $con->query($sql2);
		while ($row = $result->fetch_assoc()) {
		?>

			<p id="tongdt">Tống doanh thu từ ngày <?php echo "$tungay" ?>
				đến ngày <?php echo "$denngay" ?>
				là : <?= number_format($row['total']) ?>đ</p>
			</div>
		<?php } ?>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
	
</body>

</html>