<?php
require 'connection.php';
$bill_id=$_POST['bill_id'];
$customer_id=$_POST['customer_id'];
$status=$_POST['status'];
$sql="UPDATE `bill1` SET `status`='$status' WHERE bill_id='$bill_id'";
$result=$con->query($sql);

$sql1="UPDATE `bill_detail` SET `bill_status`='$status' WHERE bill_id='$bill_id'";
$result=$con->query($sql1);

$sql2="UPDATE `customer` SET `total`=(SELECT SUM(bill_total) FROM bill1 WHERE customer_id='$customer_id' AND status='Đã giao hàng') WHERE customer_id='$customer_id'";
$result=$con->query($sql2);
header("location:dshoadon.php");


?>