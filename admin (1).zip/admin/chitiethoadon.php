<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Chi tiết hóa đơn</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="table.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body class="body1">
	<?php
	session_start();
	require 'connection.php';
	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {
		$bill_id = $_GET['bill_id'];
	?>
		<div class="inhoadon">
			<p>PHEDRA Store</p>
		<p>Tầng 2 Vincom Xuân Khánh, Ninh Kiều, Cần Thơ</p>
		<p>Hotline: 0344109778</p>
		<center><h3>HÓA ĐƠN MUA HÀNG</h3></center>
		<?php 
			$sql1="select * from bill1 where bill_id='$bill_id'";
			$result=$con->query($sql1);
			while($row=$result->fetch_assoc()){
		?>
		<p>Tên khách hàng: <?= $row['customer_name'] ?></p>
		<p>Số điện thoại: <?= $row['customer_phonenumber'] ?></p>
		<p>Địa chỉ: <?= $row['bill_adress'] ?></p>
		<p>Ngày mua: <?= $row['bill_date'] ?></p>
		<p>Thanh toán: <?= $row['bill_status'] ?></p>
		<p>Ghi chú: <?= $row['bill_note'] ?></p>
		<?php } ?>
		</div>
			<table class="table table-triped table-hover">
				<thead>
					<tr>
						<th>Tên sản phẩm</th>
						<th>Số lượng</th>
						<th>Đơn giá</th>
						<th>Thành tiền</th>
						
					</tr>
				</thead>

				<?php
				
				$sql2 = "SELECT * FROM `bill_detail` where bill_id='$bill_id'";
				$result = $con->query($sql2);

				while ($row = $result->fetch_assoc()) {

				?>
					<tr>
						<td><?= $row['product_name'] ?></td>
						<td><?= $row['product_quantity'] ?></td>
						<td><?= number_format($row['product_price']) ?> đ</td>
						<td><?= number_format($row['bill_total']) ?> đ</td>
						
					</tr>

				<?php } ?>
			</table>
			<?php 
			$sql3="select bill_total from bill1 where bill_id='$bill_id'";
			$result=$con->query($sql3);
			while($row=$result->fetch_assoc()){


			?>
			<div class="tongcong">Tổng cộng: <?= number_format($row['bill_total']) ?> đ</div><?php } ?>
		
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
</body>

</html>