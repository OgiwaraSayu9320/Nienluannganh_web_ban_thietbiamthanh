<?php 
require 'connection.php';
$customer_name=$_POST['customer_name'];
$customer_email=$_POST['customer_email'];
$customer_numberphone=$_POST['customer_numberphone'];
$customer_password=$_POST['customer_password'];
$pw=md5($customer_password);
$sql="INSERT INTO `customer`(`customer_password`, `customer_name`, `customer_phonenumber`, `customer_email`) VALUES ('$pw','$customer_name','$customer_numberphone','$customer_email')";
$result=$con->query($sql);

header("location:index.php");
$con->close();

?>