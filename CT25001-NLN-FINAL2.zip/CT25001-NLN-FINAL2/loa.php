<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/search.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Loa di động</title>
</head>
<body>
    <nav class="navbar">
    </nav>
    <section class="search-results">
        <h2 class="heading">Loa di động</h2>
        <!-- product container-->
    <section class="product">
        <!-- <h2 class="product-category">san pham ban chay</h2> -->
        <!-- <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button> -->
        <div class="product-container">

            <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Loa' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){


            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                   
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div></a>
            <?php }

             ?>



        </div>
    </section>
    <script src="js/home.js"></script>
    </section>

    <footer class="footer-container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="img/Since_2022-removebg-preview.png" alt="">
            </div>
            <div class="footer-listmenu">
                <ul>
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="#">Tai nghe</a></li>
                    <li><a href="#">Loa di động</a></li>
                    <li><a href="#">Phụ kiện khác</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <ul>
                    <li><i class="fa-brands fa-facebook"> </i> PHEDRA STORE</li>
                    <li><i class="fa-solid fa-phone"> </i> 0123 456 789</li>
                    <li><i class="fa-solid fa-envelope"> </i> phedrastore@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"> </i> Mậu Thân, An Hoà, Ninh Kiều, Cần Thơ</li>
                </ul>
            </div>
        </div>
    </footer>

    <script src="js/nav.js"></script>
    <script src="js/footer.js"></script>
</body>
</html>