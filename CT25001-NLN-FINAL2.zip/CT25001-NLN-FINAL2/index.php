<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phedra Store</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <!-- navbar -->
    <nav class="navbar">
    </nav>

    <!-- hero-section -->
    <header class="hero-section">
        <div class="content">
            <img src="img/Since_2022-5-removebg-preview.png" class="content-logo" alt="">
            <p class="sub-heading">Sự hài lòng của bạn là phương châm của chúng tôi</p>
        </div>
    </header>

    <!-- product container-->
    <section class="product">
        <h2 class="product-category">Sản phẩm bán chạy</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
        <div class="product-container">
        <?php 
        require 'connection.php';
        $sql="SELECT * FROM `product` ORDER BY product_sold DESC LIMIT 5";
        $result=$con->query($sql);
        while($row=$result->fetch_assoc()){

        ?>
        <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?>% off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                    <button class="card-btn">Thêm vào giỏ hàng</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                                        <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div>
        </a>
            
            <?php } ?>
          
        </div>
    </section>

    <!-- collection -->
    <!-- <section class="collection-container">
        <a href="tainghecoday.php" class="collection">
            <img src="image/tainghecoday.jpeg" alt="">
            <p class="collection-title">Tai nghe có dây<br></p>
        </a>
        <a href="tainghekhongday.php" class="collection">
            <img src="image/tainghekhongday.jpg" alt="">
            <p class="collection-title">Tai nghe không dây</p>
        </a>
        <a href="loa.php" class="collection">
            <img src="image/loadidong.jpeg" alt="">
            <p class="collection-title">Loa</p>
        </a>
    </section> -->
    <!-- product -->
    <section class="product">
        <h2 class="product-category">Tai nghe có dây</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
   
               <div class="product-container">
              <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Có dây' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){


            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                   
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div></a>
            <?php }

             ?>
                
        </div>
    </section>
    <!-- product -->
    <section class="product">
        <h2 class="product-category">Tai nghe không dây</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
         <div class="product-container">
              <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Không dây' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){


            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                    <button class="card-btn">Thêm vào giỏ hàng</button>

                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div>
        </a>
            <?php }

             ?>
        </div>
    </section>
    <!-- product -->
    <section class="product">
        <h2 class="product-category">Loa di động</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
       <div class="product-container">

            <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Loa' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){

            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                    <button class="card-btn">Thêm vào giỏ hàng</button>

                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div></a>
            <?php }

             ?>

    

        </div>
    </section>

    <footer class="footer-container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="img/Since_2022-removebg-preview.png" alt="">
            </div>
            <div class="footer-listmenu">
                <ul>
                    <li><a href="index.php">TRANG CHỦ</a></li>
                    <li><a href="#">TAI NGHE CÓ DÂY</a></li>
                    <li><a href="#">TAI NGHE KHÔNG DÂY</a></li>
                    <li><a href="#">LOA DI ĐỘNG</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <ul>
                    <li><i class="fa-brands fa-facebook"> </i> PHEDRA STORE</li>
                    <li><i class="fa-solid fa-phone"> </i> 0123 456 789</li>
                    <li><i class="fa-solid fa-envelope"> </i> phedrastore@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"> </i> Mậu Thân, An Hoà, Ninh Kiều, Cần Thơ</li>
                </ul>
            </div>
        </div>
    </footer>

    <script src="js/home.js"></script>
    <script src="js/nav.js"></script>
    <!-- `` -->
</body>
</html>