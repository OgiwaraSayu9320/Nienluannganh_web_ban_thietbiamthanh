<?php
session_start();
require 'connection.php';
$customer_id=$_SESSION['customer_id'];

if(isset($_SESSION['customer_id'])){
	$product_id=$_GET['product_id'];
	$sql5="select * from bill_detail where product_quantity = 1 AND product_id='$product_id' AND bill_status=''";
	$result=$con->query($sql5);
	if ($result->num_rows > 0) {
		$sql="UPDATE `bill_detail` SET `product_quantity`=product_quantity,`bill_total`=product_quantity*product_price WHERE bill_status='' AND customer_id='$customer_id' AND product_id=".$_GET['product_id'];
	$result=$con->query($sql);

	$sql1="UPDATE `bill_detail` SET `total`=(SELECT SUM(bill_total) FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);
	
	
	header("location:cart.php");

	}else{

	$sql="UPDATE `bill_detail` SET `product_quantity`=product_quantity-1,`bill_total`=product_quantity*product_price WHERE bill_status='' AND customer_id='$customer_id' AND product_id=".$_GET['product_id'];
	$result=$con->query($sql);

	$sql1="UPDATE `bill_detail` SET `total`=(SELECT SUM(bill_total) FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);
	
	
	header("location:cart.php");}
}
else{
		header("location:login.html");
}


?>