const loader = document.querySelector('.loader');

const submitBtn = document.querySelector('.submit-btn');
const namee = document.querySelector('#name') || null;
const email = document.querySelector('#email');
const number = document.querySelector('#number') || null;
const password = document.querySelector('#password');
const tac = document.querySelector('#terms-and-cond') || null;
const notification = document.querySelector('#notification') || null;


submitBtn.addEventListener('click', () => {
    if(namee != null){
        if(namee.value.length < 10){
            showAlert('Tên phải lớn hơn hoặc bằng 10 kí tự');
        } else if(!email.value.length){
            showAlert('vui lòng nhập email của bạn!');
        } else if(!number.value.length){
            showAlert('vui long nhap so dien thoai cua ban!');
        } else if(!Number(number.value) || number.value.length < 10){
            showAlert('số điện thoại không hợp lệ! vui lòng nhập lại!');
        } else if(!password.value.length){
            showAlert('nhap mat khau cua ban!');
        } else if(password.value.length < 8){
            showAlert('mat khau phai tu 8 ki tu tro len!');
        } else if(!tac.checked){
            showAlert('ban phai dong y voi dieu khoan cua chung toi');
        } else {
            loader.style.display = 'block';
        } 
    } else{
        if(!email.value.length || !password.value.length){
            showAlert('Vui lòng điền đẩy đủ thông tin');
        } else{
            loader.style.display = 'block';
        }
    }  
})

// const sendData = (path, data) => {
//     fetch(path, {
//         method: 'post',
//         headers: new Headers({'Content-Type': 'application/json'}),
//         body: JSON.stringify(data)
//     }) .then((res) => res.json())
//     .then(response => {
//         console.log(response);
//     })
// }

const showAlert = (msg) => {
    let alertBox = document.querySelector('.alert-box');
    let alertMsg = document.querySelector('.alert-msg');

    alertMsg.innerHTML = msg;
    alertBox.classList.add('show');
    setTimeout(() => {
        alertBox.classList.remove('show');
    }, 2000);
}
