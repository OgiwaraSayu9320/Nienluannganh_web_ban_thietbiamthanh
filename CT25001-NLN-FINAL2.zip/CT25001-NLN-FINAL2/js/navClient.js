const createNav = () =>{
    let nav = document.querySelector('.navbar');
    nav.innerHTML = `
        <div class="nav">
            <a href="index.html">
            <img src="img/Since_2022-removebg-preview.png" class="logo" alt="">
            </a>
            <div class="nav-items">
                <div class="search">
                    <input type="text" class="search-box" placeholder="bạn muốn tìm gì nào..">
                    <button class="search-btn">tìm kiếm</button>
                </div>
                <a href="#">
                    <img src="img/user.png" id="user-img" alt="">
                    <div class="login-logout-popup hide">
                    <p class="account-info">Nhienpham</p>
                    <button class="btn" id="user-btn">đăng xuất</button>
                    </div>
                </a>
                <a href="#"><img src="img/cart.png" alt=""></a>
            </div>
        </div>
        <ul class="links-container">
            <li class="link-item"><a href="index.php" class="link">Trang chủ</a></li>
            <li class="link-item"><a href="#" class="link">Tai nghe không dây</a></li>
            <li class="link-item"><a href="#" class="link">Tai nghe có dây</a></li>
            <li class="link-item"><a href="#" class="link">Loa di động</a></li>
       
        </ul>
    `;
}

createNav();

// //nav popup
// const userImageButton = document.querySelector('#user-img');
// const userPopup = document.querySelector('.login-logout-popup');
// const popupText = document.querySelector('.account-info');
// const actionBtn = document.querySelector('#user-btn');

// userImageButton.addEventListener('click', () => {
//     userPopup.classList.toggle('hide');
// })

