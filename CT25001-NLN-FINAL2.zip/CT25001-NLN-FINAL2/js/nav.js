const createNav = () =>{
    let nav = document.querySelector('.navbar');
    nav.innerHTML = `
        <form action="search.php" method="POST">
        <div class="nav">
            <a href="index.php">
            <img src="img/Since_2022-removebg-preview.png" class="logo" alt="">
            </a>
            <div class="nav-items">
                <div class="search">
                
                    <input type="text" class="search-box" placeholder="bạn muốn tìm gì nào.." name="kqtk">
                    <button class="search-btn"><input type="submit" value="Tìm kiếm"></button>
                
                </div>
                <a href="suathongtin.php">
                    <img src="img/user.png" id="user-img" alt="">
                    <div class="login-logout-popup hide">
                    </div>
                </a>
                <a href="cart.php"><img src="img/cart.png" alt=""></a>
                <a href="logoutcustomer.php"><img src="img/logout.png" alt="" width="30px"></a>
            </div>
        </div>
        <ul class="links-container">
            <li class="link-item"><a href="index.php" class="link">Trang chủ</a></li>
            <li class="link-item"><a href="tainghekhongday.php" class="link">Tai nghe không dây</a></li>
             <li class="link-item"><a href="tainghecoday.php" class="link">Tai nghe có dây</a></li>
            <li class="link-item"><a href="loa.php" class="link">Loa di động</a></li>
           
        </ul></form>
    `;
}

createNav();

//nav popup
const userImageButton = document.querySelector('#user-img');
const userPopup = document.querySelector('.login-logout-popup');
const popupText = document.querySelector('.account-info');
const actionBtn = document.querySelector('#user-btn');

userImageButton.addEventListener('click', () => {
    userPopup.classList.toggle('hide');
})

