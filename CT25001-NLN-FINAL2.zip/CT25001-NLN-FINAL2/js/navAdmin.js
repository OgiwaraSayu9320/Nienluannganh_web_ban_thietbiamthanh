const createNav = () =>{
    let nav = document.querySelector('.navbar');
    nav.innerHTML = `
        <div class="nav">
            <a href="index.html">
            <img src="img/Since_2022-removebg-preview.png" class="logo" alt="">
            </a>
            <div class="nav-items">
                <div class="search">
                    <input type="text" class="search-box" placeholder="bạn muốn tìm gì nào..">
                    <button class="search-btn">tìm kiếm</button>
                </div>
                <a href="login.html">
                    <img src="img/user.png" id="user-img" alt="">
                    <div class="login-logout-popup hide">
                    </div>
                </a>
                <a href="#"><img src="img/cart.png" alt=""></a>
            </div>
        </div>
        <ul class="links-container">
            <li class="link-item"><a href="index.html" class="link">Trang chủ</a></li>
            <li class="link-item"><a href="addProduct.html" class="link">Thêm sản phẩm</a></li>
            <li class="link-item"><a href="#" class="link">Quản lý đơn hàng</a></li>
            <li class="link-item"><a href="#" class="link">Liên hệ</a></li>
        </ul>
    `;
}

createNav();

//nav popup
const userImageButton = document.querySelector('#user-img');
const userPopup = document.querySelector('.login-logout-popup');
const popupText = document.querySelector('.account-info');
const actionBtn = document.querySelector('#user-btn');

userImageButton.addEventListener('click', () => {
    userPopup.classList.toggle('hide');
})

