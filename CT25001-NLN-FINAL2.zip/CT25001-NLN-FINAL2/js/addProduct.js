const productName = document.querySelector('#product-name');
const shortDes = document.querySelector('#short-des');
const des = document.querySelector('#des');
let colors = document.querySelector('.colors');
let imagePaths = document.querySelector('.upload-catalouge');
let uploadImages = document.querySelectorAll('.fileupload');
const addProductBtn = document.querySelector('#add-btn');
const actualPrice = document.querySelector('#actual-price');
const discount = document.querySelector('#discount');
const sellerPrice = document.querySelector('#seller-price');

addProductBtn.addEventListener('click', () => {
    if(!productName.value.length){
        showAlert('nhap ten san pham');
    } else if(!shortDes.value.length){
        showAlert('nhap mo ta ngan gon');
    } else if(!des.value.length){
        showAlert('nhap mo ta chi tiet san pham');
    }  else if(!actualPrice.value.length || !discount.value.length || !sellerPrice.value.length){
        showAlert('ban phai nhap gia');
    } else {
        loader.style.display = 'block';
    }
    
})

const showAlert = (msg) => {
    let alertBox = document.querySelector('.alert-box');
    let alertMsg = document.querySelector('.alert-msg');

    alertMsg.innerHTML = msg;
    alertBox.classList.add('show');
    setTimeout(() => {
        alertBox.classList.remove('show');
    }, 2000);
}

