<?php 
$loi="";
if (isset($_POST['guimkmoi'])==true){
    $email=$_POST['email'];
    $con=new PDO("mysql:host=localhost;dbname=shop;charset=utf8","root","");
    // $con->setAttribute(PDO)
    $sql="SELECT * FROM `customer` WHERE customer_email= ?";
    $stmt=$con->prepare($sql);
    $stmt->execute([$email]);
    $count=$stmt->rowCount();
    if($count==0){
        $loi="Email chưa được đăng ký thành viên";
    }else{
        $matkhaumoi=substr(md5(rand(0,99)), 0, 8);
        $pass=md5($matkhaumoi);
        $sql="UPDATE `customer` SET `customer_password`=? WHERE customer_email=?";
        $stmt=$con->prepare($sql);
        $stmt->execute([$pass,$email]);
        
        Updatepass($email,$matkhaumoi);
    }

}


?>

<?php 
function Updatepass($email,$matkhaumoi){
    require "PHPMailer-master/src/PHPMailer.php"; 
    require "PHPMailer-master/src/SMTP.php"; 
    require 'PHPMailer-master/src/Exception.php'; 
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);//true:enables exceptions
    try {
        $mail->SMTPDebug = 0; //0,1,2: chế độ debug
        $mail->isSMTP();  
        $mail->CharSet  = "utf-8";
        $mail->Host = 'smtp.gmail.com';  //SMTP servers
        $mail->SMTPAuth = true; // Enable authentication
        $mail->Username = 'boihungwork@gmail.com'; // SMTP username
        $mail->Password = '0344109778nbhung';   // SMTP password
        $mail->SMTPSecure = 'ssl';  // encryption TLS/SSL 
        $mail->Port = 465;  // port to connect to                
        $mail->setFrom('boihungwork@gmail.com', 'Music' ); 
        $mail->addAddress($email); 
        $mail->isHTML(true);  // Set email format to HTML
        $mail->Subject = 'Quên mật khẩu';
        $noidungthu = "<p>Do nhận được yêu cầu đổi mật khẩu nên chúng tôi sẽ gửi cho bạn mật khẩu mới.</p><br> 
        <p>Mật khẩu mới là</p> <h3>{$matkhaumoi}</h3><br>
        <p>Bạn nên đăng nhập sau đó đổi mật khẩu để đảm bảo sự bảo mật.</p>
        "; 
        $mail->Body = $noidungthu;
        $mail->smtpConnect( array(
            "ssl" => array(
                "verify_peer" => false,
                "verify_peer_name" => false,
                "allow_self_signed" => true
            )
        ));
        $mail->send();
        header("location:login.html");
    } catch (Exception $e) {
        echo 'Error: ', $mail->ErrorInfo;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <img src="img/loader.gif" class="loader" alt="">
    <div class="alert-box">
        <img src="img/error.png" class="alert-img" alt="">
        <p class="alert-msg">Error Message</p>
    </div>
    
    <div class="container">
        <a href="index.php">
            <a href="index.php"><img src="img/Since_2022-removebg-preview.png" class="logo" alt=""></a>
        </a>
        <form method="POST">
       
            <input type="email" autocomplete="off" id="email" placeholder="Email" name="email" value="<?php if(isset($email)==true ) echo $email   ?>">
                <?php if($loi!=""){ ?>
            <div class="thongbao"><span>  <?=$loi?>  </span></div>
            <?php }    ?>
            <input type="submit" class="submit-btn" name="guimkmoi" value="Gửi mật khẩu mới">
        </form>
        </div>
    </div>
    <script src="js/form.js"></script>
</body>
</html>