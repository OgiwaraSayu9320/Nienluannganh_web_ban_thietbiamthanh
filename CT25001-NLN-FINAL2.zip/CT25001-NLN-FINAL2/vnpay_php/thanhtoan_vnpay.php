<?php 
session_start();
require '../connection.php';
if(isset($_SESSION['customer_id'])){
$customer_id=$_SESSION['customer_id'];
$customer_name=$_POST['customer_name'];
$customer_phonenumber=$_POST['customer_phonenumber'];
date_default_timezone_set('Asia/Ho_Chi_Minh');
$sonha=$_POST['sonha'];
$tenduong=$_POST['tenduong'];
$xaphuong=$_POST['xaphuong'];
$huyenquan=$_POST['huyenquan'];
$tinhtp=$_POST['tinhtp'];
$today=date("Y-n-j");
$month=date("n");
$year=date("Y");
$total=$_POST['total'];
$note=$_POST['note'];
$sql="INSERT INTO `bill1`(`customer_id`, `customer_name`,`customer_phonenumber`, `bill_total`, `bill_date`, `bill_status`, `bill_adress`, `bill_note`) VALUES ('$customer_id','$customer_name','$customer_phonenumber','$total','$today','','$sonha, $tenduong,$xaphuong,$huyenquan,$tinhtp','$note')";
    $result=$con->query($sql);
    
    $sql1="UPDATE `bill_detail` SET `bill_status`='Đã xác nhận',`bill_id`=(SELECT MAX(bill_id) FROM `bill1` WHERE customer_id='$customer_id') WHERE customer_id='$customer_id' AND bill_status=''";
    $result=$con->query($sql1);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Thanh toán đơn hàng</title>
        <!-- Bootstrap core CSS -->
        <link href="assets/bootstrap.min.css" rel="stylesheet"/>
        <!-- Custom styles for this template -->
        <link href="assets/jumbotron-narrow.css" rel="stylesheet">  
        <script src="assets/jquery-1.11.3.min.js"></script>
    </head>

    <body>
        <?php require_once("./config.php"); 
        
      

        ?>             
        <div class="container">
            <div class="header clearfix">
                <h3 class="text-muted">VNPAY</h3>
            </div>
            <h3>Thanh toán đơn hàng</h3>
            <div class="table-responsive">
                <form action="vnpay_create_payment.php" id="create_form" method="post">       

                    <div class="form-group">
                        <label for="language">Loại hàng hóa </label>
                        <select name="order_type" id="order_type" class="form-control">
                            
                            <option value="billpayment">Thanh toán hóa đơn</option>
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="order_id">Mã hóa đơn</label>
                        <?php 
                        require '../connection.php';
                            $sql7="select bill_id from bill1 where bill_id=(SELECT MAX(bill_id) FROM `bill1` WHERE customer_id='$customer_id') ";
                            $result=$con->query($sql7);
                            while($row=$result->fetch_assoc()){
                        ?>
                        <input class="form-control" id="order_id" name="order_id" type="hidden" value="<?=$row['bill_id'] ?>"/>
                        <p class="form-control"><?=$row['bill_id'] ?></p>
                    <?php } ?>
                    </div>
                    <div class="form-group">
                        <label for="amount">Số tiền</label>
                        <input class="form-control" id="amount"
                               name="amount" type="hidden" value="<?php echo $total ?>"  />
                        <p class="form-control"><?php echo $total?></p>
                    </div>
                    <div class="form-group">
                        <label for="order_desc">Nội dung thanh toán</label>
                        <textarea class="form-control" cols="20" id="order_desc" name="order_desc" rows="2">Thanh toán hóa đơn</textarea>
                    </div>
                    <div class="form-group">
                        <label for="bank_code">Ngân hàng</label>
                        <select name="bank_code" id="bank_code" class="form-control">
                            <option value="">Không chọn</option>
                            <option value="NCB"> Ngan hang NCB</option>
                            <option value="AGRIBANK"> Ngan hang Agribank</option>
                            <option value="SCB"> Ngan hang SCB</option>
                            <option value="SACOMBANK">Ngan hang SacomBank</option>
                            <option value="EXIMBANK"> Ngan hang EximBank</option>
                            <option value="MSBANK"> Ngan hang MSBANK</option>
                            <option value="NAMABANK"> Ngan hang NamABank</option>
                            <option value="VNMART"> Vi dien tu VnMart</option>
                            <option value="VIETINBANK">Ngan hang Vietinbank</option>
                            <option value="VIETCOMBANK"> Ngan hang VCB</option>
                            <option value="HDBANK">Ngan hang HDBank</option>
                            <option value="DONGABANK"> Ngan hang Dong A</option>
                            <option value="TPBANK"> Ngân hàng TPBank</option>
                            <option value="OJB"> Ngân hàng OceanBank</option>
                            <option value="BIDV"> Ngân hàng BIDV</option>
                            <option value="TECHCOMBANK"> Ngân hàng Techcombank</option>
                            <option value="VPBANK"> Ngan hang VPBank</option>
                            <option value="MBBANK"> Ngan hang MBBank</option>
                            <option value="ACB"> Ngan hang ACB</option>
                            <option value="OCB"> Ngan hang OCB</option>
                            <option value="IVB"> Ngan hang IVB</option>
                            <option value="VISA"> Thanh toan qua VISA/MASTER</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="language">Ngôn ngữ</label>
                        <select name="language" id="language" class="form-control">
                            <option value="vn">Tiếng Việt</option>
                            <option value="en">English</option>
                        </select>
                    </div>
                  
                        <input class="form-control" id="txtexpire"
                               name="txtexpire" type="hidden" value="<?php echo $expire; ?>"/>
               
                   
                        <input class="form-control" id="txt_billing_fullname"
                               name="txt_billing_fullname" type="hidden" value="NGUYEN VAN XO"/>             
            
                        <input class="form-control" id="txt_billing_email"
                               name="txt_billing_email" type="hidden" value="xonv@vnpay.vn"/>   
             
                        <input class="form-control" id="txt_billing_mobile"
                               name="txt_billing_mobile" type="hidden" value="0934998386"/>   
              
                        <input class="form-control" id="txt_billing_addr1"
                               name="txt_billing_addr1" type="hidden" value="22 Lang Ha"/>   
                   
                    
                        <input class="form-control" id="txt_postalcode"
                               name="txt_postalcode" type="hidden" value="100000"/> 
                   
                
                        <input class="form-control" id="txt_bill_city"
                               name="txt_bill_city" type="hidden" value="Hà Nội"/> 
                  
                        <input class="form-control" id="txt_bill_state"
                               name="txt_bill_state" type="hidden" value=""/>
                    
                   
                        <input class="form-control" id="txt_bill_country"
                               name="txt_bill_country" type="hidden" value="VN"/>
                   
                 
            
                        <input class="form-control" id="txt_ship_fullname"
                               name="txt_ship_fullname" type="hidden" value="Nguyễn Thế Vinh"/>
            
                   
                        <input class="form-control" id="txt_ship_email"
                               name="txt_ship_email" type="hidden" value="vinhnt@vnpay.vn"/>
              
                  
                        <input class="form-control" id="txt_ship_mobile"
                               name="txt_ship_mobile" type="hidden" value="0123456789"/>
                   
                   
                        <input class="form-control" id="txt_ship_addr1"
                               name="txt_ship_addr1" type="hidden" value="Phòng 315, Công ty VNPAY, Tòa nhà TĐL, 22 Láng Hạ, Đống Đa, Hà Nội"/>
                 
                    
                        <input class="form-control" id="txt_ship_postalcode"
                               name="txt_ship_postalcode" type="hidden" value="1000000"/>
                   
                    
                        <input class="form-control" id="txt_ship_city"
                               name="txt_ship_city" type="hidden" value="Hà Nội"/>
                   
               
                        <input class="form-control" id="txt_ship_state"
                               name="txt_ship_state" type="hidden" value=""/>
                    
                     
                        <input class="form-control" id="txt_ship_country"
                               name="txt_ship_country" type="hidden" value="VN"/>
         
                
                        <input class="form-control" id="txt_inv_customer"
                               name="txt_inv_customer" type="hidden" value="Lê Văn Phổ"/>
                   
           
                        <input class="form-control" id="txt_inv_company"
                               name="txt_inv_company" type="hidden" value="Công ty Cổ phần giải pháp Thanh toán Việt Nam"/>
                
               
                        <input class="form-control" id="txt_inv_addr1"
                               name="txt_inv_addr1" type="hidden" value="22 Láng Hạ, Phường Láng Hạ, Quận Đống Đa, TP Hà Nội"/>
                 
                    
                        
                        <input class="form-control" id="txt_inv_taxcode"
                               name="txt_inv_taxcode" type="hidden" value="0102182292"/>
                   
                  <input type="hidden" name="cbo_inv_type" value="I">
                    
                        <input class="form-control" id="txt_inv_email"
                               name="txt_inv_email" type="hidden" value="pholv@vnpay.vn"/>
                    
                  
                        <input class="form-control" id="txt_inv_mobile"
                               name="txt_inv_mobile" type="hidden" value="02437764668"/>
                 
                    
                    <button type="submit" name="redirect" id="redirect" class="btn btn-default">Thanh toán</button>

                </form>
            </div>
            <p>
                &nbsp;
            </p>
            <footer class="footer">
                <p>&copy; VNPAY <?php echo date('Y')?></p>
            </footer>
        </div>  
       
         


    </body>
</html>
<?php 

} else{
    header("location:../login.html");
}
?>