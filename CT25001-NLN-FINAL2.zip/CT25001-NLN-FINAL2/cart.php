<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<?php 
session_start();
require 'connection.php';
$customer_id=$_SESSION['customer_id'];
if(isset($_SESSION['customer_id']))
{
    ?>
    <nav class="navbar"></nav>
    
    <div class="cart-section">
        <div class="product-list">
            <p class="section-heading">Giỏ hàng của bạn</p>
            <div class="cart">
                <!-- san pham da dua vao gio hang -->
                <?php
                $sql="SELECT * FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status=''";
                $result=$con->query($sql);
                while($row=$result->fetch_assoc()){


                ?>

                <div class="cart-product">

                    <img src="<?=$row['product_image']?>" class="cart-product-img" alt="">
                    <div class="cart-text">
                        <p class="cart-product-name"><?=$row['product_name']?></p>
                      
                    </div>
                    <div class="item-counter">
                        <a href="phpminusproduct.php?product_id=<?=$row['product_id']?>"><button class="counter-btn decrement">-</button></a>
                        <p class="item-count"><?=$row['product_quantity']?></p>
                        <a href="phpplusproduct.php?product_id=<?=$row['product_id']?>"><button class="counter-btn increment">+</button></a>
                    </div>
                    <p class="cart-price"><?=number_format($row['bill_total'])?>đ</p>
                    <a href="phpxoacart.php?product_id=<?=$row['product_id']?>"><button class="cart-delete-btn"><img src="img/close.png" alt=""></button></a>
                </div>


            <?php } ?> 


               




            </div>
      
        </div>
        <div class="checkout-section">
            <div class="checkout-box">
                <p class="text">Tổng cộng</p>
                <?php 
                $sql1="SELECT DISTINCT`total` FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status=''";
                $result=$con->query($sql1);
                while($row = $result->fetch_assoc()) { ?>
                <h3 class="bill"><?=number_format($row['total'])?>đ</h3>
            <?php } ?>
                <a href="checkout.php" class="checkout-btn">Thanh toán</a>
            </div>
        </div>
    </div>

    <footer class="footer-container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="img/Since_2022-removebg-preview.png" alt="">
            </div>
            <div class="footer-listmenu">
                <ul>
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="#">Tai nghe</a></li>
                    <li><a href="#">Loa di động</a></li>
                    <li><a href="#">Phụ kiện khác</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <ul>
                    <li><i class="fa-brands fa-facebook"> </i> PHEDRA STORE</li>
                    <li><i class="fa-solid fa-phone"> </i> 0123 456 789</li>
                    <li><i class="fa-solid fa-envelope"> </i> phedrastore@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"> </i> Mậu Thân, An Hoà, Ninh Kiều, Cần Thơ</li>
                </ul>
            </div>
        </div>
    </footer>


    <script src="js/nav.js"></script>
    <script src="js/home.js"></script>
    <script src="js/cart.js"></script>
    <script src="js/footer.js"></script>
<?php 
}
else{
    header("location:login.html");
}?>
</body>
</html>