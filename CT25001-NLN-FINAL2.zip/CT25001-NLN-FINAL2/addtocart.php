<?php 
session_start();
require 'connection.php';
if (isset($_SESSION['customer_id'])) {
	$customer_id=$_SESSION['customer_id'];
	$product_name=$_POST['product_name'];
	$product_price=$_POST['product_price'];
	$product_id=$_POST['product_id'];
	$product_image=$_POST['product_image'];
	$today = date("F j, Y");
	
	$sql5="select * from bill_detail where product_id='$product_id' AND customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql5);
	if ($result->num_rows > 0) {
			$sql="UPDATE `bill_detail` SET `product_quantity`=product_quantity + 1 WHERE bill_status='' AND product_id='$product_id' AND customer_id='$customer_id'";
	$result=$con->query($sql);


		$sql2="UPDATE `bill_detail` SET `bill_total`=product_quantity*product_price WHERE bill_status='' AND product_id='$product_id' AND customer_id='$customer_id'";
	$result=$con->query($sql2);

	$sql1="UPDATE `bill_detail` SET `total`=(SELECT SUM(bill_total) FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);
	header("location:cart.php");
	}else{

	$sql="INSERT INTO `bill_detail`( `customer_id`, `product_id`, `product_name`, `product_image`, `product_price`, `product_quantity`, `bill_total`, `bill_status`) VALUES ('$customer_id','$product_id','$product_name','$product_image','$product_price','1','','')";
	$result=$con->query($sql);


	$sql2="UPDATE `bill_detail` SET `bill_total`=product_quantity*product_price WHERE bill_status='' AND product_id='$product_id' AND customer_id='$customer_id'";
	$result=$con->query($sql2);

	$sql1="UPDATE `bill_detail` SET `total`=(SELECT SUM(bill_total) FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);

	header("location:cart.php");}
}else{
	header("location:login.html");
}


?>