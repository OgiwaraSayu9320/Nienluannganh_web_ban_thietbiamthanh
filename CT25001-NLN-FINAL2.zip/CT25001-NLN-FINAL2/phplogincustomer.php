<?php
session_start();
$customer_email=$_POST['customer_email'];
$mk=$_POST['customer_password'];
$pass=md5($mk);
require 'connection.php';
$sql="select * from customer where customer_email='$customer_email' and customer_password='$pass'";
$result=$con->query($sql);
$row = $result->fetch_assoc();

$_SESSION['customer_id'] = $row['customer_id'];

if ($result->num_rows > 0) {
	header("Location:index.php");

} else { 
	header("Location:login.html") ;}

$con->close();
?>
