<?php 
require 'connection.php';
$product_id=$_GET['product_id'];
$sql="SELECT * FROM `product` WHERE product_id='$product_id'";
$result=$con->query($sql);
while ($row=$result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$row['product_name']?></title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/product.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
    <!-- start navbar -->
    <nav class="navbar">
    </nav>
    <!-- end navbar -->

    <section class="product-details">
        <div class="image-slider" style="background-image: url(<?=$row['product_image']?>); background-size:100%;">
            <div class="product-images">
                <img src="<?=$row['product_image']?>" class="active" alt="">
                <img src="<?=$row['product_image1']?>" alt="">
                <img src="<?=$row['product_image2']?>" alt="">
                <img src="<?=$row['product_image3']?>" alt="">
            </div>
        </div>
        <div class="details">
            <h2 class="product-brand"><?=$row['product_name']?></h2>
            <p class="product-short-des"></p>
            <span class="product-price"><?=number_format($row['product_price'])?>đ</span>
            <sapn class="product-actual-price"><?=number_format($row['giagiam'])?></sapn>
            <span class="product-discount">(-<?=$row['giam']?>%)</span>

           
            <form action="addtocart.php" method="POST">
                <input type="hidden" name="product_id" value="<?=$row['product_id']?>">
                <input type="hidden" name="product_name" value="<?=$row['product_name']?>">
                <input type="hidden" name="product_image" value="<?=$row['product_image']?>">
                <input type="hidden" name="product_price" value="<?=$row['product_price']?>">
                <input type="submit" class="btn cart-btn" name="" value="Thêm vào giỏ hàng">
            </form>
            
            
        </div>
    </section>

    <section class="detail-des">
        <h2 class="heading">Mô tả sản phẩm</h2>
        <p class="des"><?=$row['chitiet']?></p>
        <h2 class="heading1">Thông số chi tiết</h2>
        <table id="table">
            <tr>
                <td>Pin</td>
                <td><?=$row['pin']?></td>
            </tr>
             <tr>
                <td>Cổng sạc</td>
                <td><?=$row['congsac']?></td>
            </tr>
             <tr>
                <td>Công nghệ âm thanh</td>
                <td><?=$row['congngheamthanh']?></td>
            </tr>
             <tr>
                <td>Tương thích</td>
                <td><?=$row['tuongthich']?></td>
            </tr>
             <tr>
                <td>Tiện ích</td>
                <td><?=$row['tienich']?></td>
            </tr>
             <tr>
                <td>Hỗ trợ kết nối</td>
                <td><?=$row['hotroketnoi']?></td>
            </tr>
             <tr>
                <td>Điều khiển</td>
                <td><?=$row['dieukhien']?></td>
            </tr> 
        </table>
    </section>
<?php } ?>
    <!-- product -->
    <section class="product">
        <h2 class="product-category">Loa di động</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
        <div class="product-container">

            <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Loa' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){


            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                   
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div></a>
            <?php }

             ?>



        </div>
    </section>
    <!-- product -->
    <section class="product">
        <h2 class="product-category">Tai nghe không dây</h2>
        <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button>
        <div class="product-container">
              <?php
                require 'connection.php';
                $sql="select * from product where product_type = 'Không dây' ";
                $result=$con->query($sql);

                   while($row=$result->fetch_assoc()){


            ?>
            <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                   
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div>
        </a>
            <?php }

             ?>
        </div>
    </section>

    <footer class="footer-container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="img/Since_2022-removebg-preview.png" alt="">
            </div>
            <div class="footer-listmenu">
                <ul>
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="#">Tai nghe</a></li>
                    <li><a href="#">Loa di động</a></li>
                    <li><a href="#">Phụ kiện khác</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <ul>
                    <li><i class="fa-brands fa-facebook"> </i> PHEDRA STORE</li>
                    <li><i class="fa-solid fa-phone"> </i> 0123 456 789</li>
                    <li><i class="fa-solid fa-envelope"> </i> phedrastore@gmail.com</li>
                    <li><i class="fa-solid fa-location-dot"> </i> Mậu Thân, An Hoà, Ninh Kiều, Cần Thơ</li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="js/nav.js"></script>
    <script src="js/home.js"></script>
    <script src="js/footer.js"></script>
    <script src="js/product.js"></script>


    
</body>
</html>