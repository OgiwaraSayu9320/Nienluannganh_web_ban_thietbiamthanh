<?php 
session_start();
require 'connection.php';

if (isset($_SESSION['customer_id'])) {
	$product_id=$_GET['product_id'];
	$customer_id=$_SESSION['customer_id'];
	$sql="DELETE FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='' AND product_id='$product_id'" ;
	$result=$con->query($sql);
	
	$sql1="UPDATE `bill_detail` SET `total`=(SELECT SUM(bill_total) FROM `bill_detail` WHERE customer_id='$customer_id' AND bill_status='') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);
	header("location:cart.php");
}else{
	header("location:login.html");
}


?>