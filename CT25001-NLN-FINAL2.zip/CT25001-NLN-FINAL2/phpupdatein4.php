<?php 
require 'connection.php';
session_start();
$customer_id=$_SESSION['customer_id'];
if(isset($_SESSION['customer_id'])){
	$customer_name=$_POST['customer_name'];
	$customer_phonenumber=$_POST['customer_phonenumber'];
	$customer_address=$_POST['customer_address'];
	$sql="UPDATE `customer` SET `customer_name`='$customer_name',`customer_phonenumber`='$customer_phonenumber',`customer_address`='$customer_address' WHERE customer_id='$customer_id'";
	$result=$con->query($sql);
	header("location:suathongtin.php");
}else{
	header("location:login.html");
}

?>