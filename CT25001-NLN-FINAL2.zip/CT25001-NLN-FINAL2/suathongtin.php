<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <?php 
    session_start();
require 'connection.php';
$customer_id=$_SESSION['customer_id'];

    if(isset($_SESSION['customer_id'])){
            $sql="SELECT * FROM `customer` WHERE customer_id='$customer_id'";
            $result=$con->query($sql);
            while($row=$result->fetch_assoc()){
    ?>
    <img src="img/loader.gif" class="loader" alt="">
    <div class="alert-box">
        <img src="img/error.png" class="alert-img" alt="">
        <p class="alert-msg">Error Message</p>
    </div>
    
    <div class="container">
        <a href="index.php">
            <a href="index.php"><img src="img/Since_2022-removebg-preview.png" class="logo" alt=""></a>
        </a>
        <form action="phpupdatein4.php" method="POST">
            <input type="text" autocomplete="off" id="name" placeholder="Họ và tên" value="<?=$row['customer_name']?>" name="customer_name">
            <!-- <div class="form__input-error-message"></div> -->
            <input type="email" autocomplete="off" id="email" placeholder="Email" value="<?=$row['customer_email']?>" disabled>
            <input type="text" autocomplete="off" id="number" placeholder="Số điện thoại" value="<?=$row['customer_phonenumber']?>" name="customer_phonenumber">
            
            
            <input type="submit" class="submit-btn" name="" value="Cập nhật thông tin">
            
        </form>
            
        </div>
    </div>
    <script src="js/form.js"></script>

<?php }}
else{
    header("location:login.html");
}

 ?>
</body>
</html>