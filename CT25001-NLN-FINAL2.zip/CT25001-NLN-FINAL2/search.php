<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/search.css">
      <link rel="stylesheet" href="css/product.css">
      <link rel="stylesheet" href="css/footer.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Search</title>
</head>
<body>
    <nav class="navbar">
    </nav>
    <section class="search-results">
        <?php
            require 'connection.php';
            $kqtk=$_POST['kqtk'];
            $sql="select * from product where (product_name like '%".$kqtk."%')";
            $result=$con->query($sql);


        ?>
        <h2 class="heading">Kết quả tìm kiếm cho <span><?php echo "$kqtk"; ?></span></h2>
        <!-- product container-->
    <section class="product">
         <div class="product-container">
        <!-- <h2 class="product-category">san pham ban chay</h2> -->
        <!-- <button class="pre-btn"><img src="img/arrow.png" alt=""></button>
        <button class="nxt-btn"><img src="img/arrow.png" alt=""></button> -->
        <?php    while($row=$result->fetch_assoc()){ ?>
       <a href="product.php?product_id=<?=$row['product_id']?>">
            <div class="product-card">
                <div class="product-img">
                    <span class="discount-tag"><?=$row['giam']?> off</span>
                    <img src="<?=$row['product_image']?>" class="product-thumb" alt="">
                   
                </div>
                <div class="product-info">
                    <h2 class="product-brand"><?=$row['product_name']?></h2>
                  
                    <span class="price"><?=number_format($row['product_price'])?>đ</span> <span class="actual-price"><?=number_format($row['giagiam'])?>đ</span>
                </div>
            </div></a>
        <?php } ?>
    </div>
    </section>

    <footer class="footer-container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="img/Since_2022-removebg-preview.png" alt="">
            </div>
            <div class="footer-listmenu">
                <ul>
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="#">Tai nghe</a></li>
                    <li><a href="#">Loa di động</a></li>
                    <li><a href="#">Phụ kiện khác</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <ul>
                    <li><i class="fa-brands fa-facebook"></i></li>
                    <li><i class="fa-solid fa-phone"></i></li>
                    <li><i class="fa-solid fa-envelope"></i></li>
                    <li><i class="fa-solid fa-location-dot"></i></li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="js/home.js"></script>
    </section>
    <footer></footer>
    <script src="js/nav.js"></script>
    <script src="js/footer.js"></script>
</body>
</html>