<?php 
require 'connection.php';
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$customer_id=$_SESSION['customer_id'];
$customer_name=$_POST['customer_name'];
$customer_phonenumber=$_POST['customer_phonenumber'];
$sonha=$_POST['sonha'];
$tenduong=$_POST['tenduong'];
$xaphuong=$_POST['xaphuong'];
$huyenquan=$_POST['huyenquan'];
$tinhtp=$_POST['tinhtp'];
$today=date("Y-n-j");
$month=date("n");
$year=date("Y");
$total=$_POST['total'];
$note=$_POST['note'];

if(isset($_SESSION['customer_id'])){
	$sql="INSERT INTO `bill1`(`customer_id`, `customer_name`,`customer_phonenumber`, `bill_total`, `bill_date`, `bill_status`, `bill_adress`, `bill_note`) VALUES ('$customer_id','$customer_name','$customer_phonenumber','$total','$today','Thanh toán nhận hàng','$sonha, $tenduong,$xaphuong,$huyenquan,$tinhtp','$note')";
	$result=$con->query($sql);
	
	$sql1="UPDATE `bill_detail` SET `bill_status`='Đã xác nhận',`bill_id`=(SELECT MAX(bill_id) FROM `bill1` WHERE customer_id='$customer_id') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);

	

	

	header("location:thankyou.html");
	$con->close();
}else{
	header("location:login.html");
}

?>