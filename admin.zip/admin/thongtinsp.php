<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manager</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
	session_start();

$admin_id=$_SESSION['admin_id'];

if(isset($_SESSION['admin_id'])){

?>
	<div class="menu">
		<ul>
			<li>
				<a href="index.php">Trang chủ</a>
			</li>
			<li>
				<a href="danhsach.php">Danh sách sản phẩm</a>
			</li>
			<li>
				<a href="themhanghoa.php">Thêm hàng hóa</a>
			</li>
			<li>
				<a href="">Nhập hàng vào kho</a>
			</li>
			<li>
				<a href="">Danh sách hóa đơn</a>
			</li>
			<li>
				<a href="chitiethoadon.php">Chi tiết hóa đơn</a>
			</li>
			<li>
				<a href="">Danh sách khách hàng</a>
			</li>
			
		</ul>
	</div>
	<?php 
					require 'connection.php';
					
					$sql="SELECT * FROM `product` WHERE product_id=".$_GET['product_id'];
					$result=$con->query($sql);
					while($row = $result->fetch_assoc()){					
	?>
	<div class="content">
		<div class="thongtinsp">
			<h2>THÔNG TIN SẢN PHẨM</h2>
			<form action="phpthemthongtinsp.php" enctype="multipart/form-data" method="POST">
				<label><?=$row['product_name']?></label> 				
				<input type="hidden" name="product_id" value="<?=$row['product_id']?>"><br>
				<input type="hidden" name="product_name" value="<?=$row['product_name']?>">
				<label>Ảnh sản phẩm</label>
				<input type="file" name="product_image2"><br>
				<label>Mô tả chi tiết sản phẩm</label><br>
				<textarea cols="60" rows="20" name="product_discription"></textarea><br>
				<input type="hidden" name="product_quanlity" value="0">
				<input type="hidden" name="product_sold" value="0">
				<input type="submit" name="" value="Thêm"><input type="reset" name="" value="Hủy">



				<?php } ?>
			</form>
		</div>
		
	</div>
<?php 
}
else{
	header("location:loginadmin.html");
};
?>
</body>
</html>