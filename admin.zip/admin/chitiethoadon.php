<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Chi tiết hóa đơn</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="table.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body class="body1">
	<?php
	session_start();
	require 'connection.php';
	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
			<hr>
			<ul>
				<li>
					<a href="index.php">Thêm hàng hóa</a>
				</li>

				<li>
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>
				<li>
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>
			
				<li>
					<a href="doanhthu.php">Doanh thu</a>
				</li>
				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>
				<li>
					<a href="logoutadmin.php"><i class="fas fa-sign-out"></i> Đăng xuất</a>

				</li>


				<?php
				require 'connection.php';
				$sql = "select * from admin where admin_id='$admin_id'";
				$result = $con->query($sql);
				while ($row = $result->fetch_assoc()) {
				?>
					
					<li><a href="#"><i class="fas fa-user"> </i> <?= $row['admin_name'] ?></a>
					</li>

				<?php
				}


				?>

			</ul>
		</div>

		<div class="content">
			<table class="table table-triped table-hover">
				<thead>
					<tr>
						<th>Tên sản phẩm</th>
						<th>Số lượng</th>
						<th>Đơn giá</th>
						<th>Thành tiền</th>
						<th>Trạng thái</th>
					</tr>
				</thead>

				<?php
				$bill_id = $_GET['bill_id'];
				$sql2 = "SELECT * FROM `bill_detail` where bill_id='$bill_id'";
				$result = $con->query($sql2);

				while ($row = $result->fetch_assoc()) {

				?>
					<tr>
						<td><?= $row['product_name'] ?></td>
						<td><?= $row['product_quantity'] ?></td>
						<td><?= $row['product_price'] ?></td>
						<td><?= $row['bill_total'] ?></td>
						<td><?= $row['bill_status'] ?></td>
					</tr>

				<?php } ?>
			</table>
		</div>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
</body>

</html>