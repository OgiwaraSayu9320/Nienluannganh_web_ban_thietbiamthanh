<?php 
require 'connection.php';
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
$customer_id=$_SESSION['customer_id'];
$customer_name=$_POST['customer_name'];
$customer_phonenumber=$_POST['customer_phonenumber'];
$customer_address=$_POST['customer_address'];
$today=date("Y-n-j");
$month=date("n");
$year=date("Y");
$total=$_POST['total'];
$note=$_POST['note'];
$product_id=$_POST['product_id'];
$product_quantity=$_POST['product_quantity'];

if(isset($_SESSION['customer_id'])){
	$sql="INSERT INTO `bill1`(`customer_id`, `customer_name`,`customer_phonenumber`, `bill_total`, `bill_date`, `bill_status`, `bill_adress`, `bill_note`) VALUES ('$customer_id','$customer_name','$customer_phonenumber','$total','$today','','$customer_address','$note')";
	$result=$con->query($sql);
	
	$sql1="UPDATE `bill_detail` SET `bill_status`='Đã xác nhận',`bill_id`=(SELECT MAX(bill_id) FROM `bill1` WHERE customer_id='$customer_id') WHERE customer_id='$customer_id' AND bill_status=''";
	$result=$con->query($sql1);

	$sql2="UPDATE `product` SET`product_quantity`=product_quantity-'$product_quantity',`product_sold`=product_sold + '$product_quantity' WHERE product_id='$product_id'";
	$result=$con->query($sql2);

	$sql3="INSERT INTO `turnover`(`ngay`, `DTngay`, `thang`, `DTthang`, `nam`, `DTnam`) VALUES ('$today','$total','Tháng $month',(SELECT  sum(bill_total)  from bill1 WHERE month(bill_date)=$month),'Năm $year',(SELECT  sum(bill_total)  from bill1 WHERE year(bill_date)=$year))";
	$result=$con->query($sql3);

	header("location:index.php");
	$con->close();
}else{
	header("location:logincustomer.html");
}

?>