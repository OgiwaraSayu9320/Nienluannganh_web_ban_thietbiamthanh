<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hóa đơn</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="danhsachhoadon.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body class="body1">

	<?php
	session_start();
	require 'connection.php';
	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
			<hr>
			<ul>
				<li>
					<a href="index.php">Thêm hàng hóa</a>
				</li>

				<li>
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>
				<li class="menu-item">
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>
				
				<li>
					<a href="doanhthu.php">Doanh thu</a>
				</li>
				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>
				<li>
				<a href="logoutadmin.php"><i class="fas fa-sign-out"></i> Đăng xuất</a>
				</li>


				<?php
				require 'connection.php';
				$sql = "select * from admin where admin_id='$admin_id'";
				$result = $con->query($sql);
				while ($row = $result->fetch_assoc()) {
				?>
					<li><a href="#"><i class="fas fa-user"> </i> <?= $row['admin_name'] ?></a>
					</li>

				<?php
				}


				?>

			</ul>
		</div>

		<div class="content">
			<table class="tablehd tablehd-triped tablehd-hover">
				<thead>
					<tr>
						<th>Họ tên khách hàng</th>
						<th>Số điện thoại</th>
						<th>Tổng hóa đơn</th>
						<th>Chi tiết</th>
						<th>Địa chỉ</th>
						<th>Ngày</th>
						<th>Ghi chú</th>
						<th>Trạng thái</th>

					</tr>
				</thead>

				<?php
				$sql3 = "SELECT * FROM `bill1` ORDER BY bill_id DESC";
				$result = $con->query($sql3);
				while ($row = $result->fetch_assoc()) {
				?>
					<tr>
						<td><?= $row['customer_name'] ?></td>
						<td><?= $row['customer_phonenumber'] ?></td>
						<td><?=number_format($row['bill_total']) ?>đ</td>
						<td><a href="chitiethoadon.php?bill_id=<?= $row['bill_id'] ?>"><button>Xem</button></a></td>
						<td><?= $row['bill_adress'] ?></td>
						<td width="80px"><?= $row['bill_date'] ?></td>
						<td><?= $row['bill_note'] ?></td>

						<form action="phpthemtrangthai.php" method="POST">
							<input type="hidden" name="customer_id" value="<?= $row['customer_id'] ?>">
							<input type="hidden" name="bill_id" value="<?= $row['bill_id'] ?>">
							<td width="150px"><select name="status">
									<option><?= $row['status'] ?></option>
									<option value="Đã giao hàng">Đã giao hàng</option>
									<option value="Đã hủy">Đã hủy</option>
								</select><input type="submit" value="Lưu" name=""></td>
						</form>
					</tr>



				<?php } ?>
			</table>
		</div>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
</body>

</html>