<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Thêm hàng hóa</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="themhh.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
</head>

<body class="body1">
	<?php
	session_start();

	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
			<hr>
			<ul>
				<li class="menu-item">
					<a href="index.php">Thêm hàng hóa</a>
				</li>

				<li>
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>
				<li>
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>
				
				<li>
					<a href="doanhthu.php">Doanh thu</a>
				</li>
				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>
				<div class="logout">
					<li>
					<a href="logoutadmin.php"><i class="fas fa-sign-out"></i> Đăng xuất</a>
					</li>

					<?php
					require 'connection.php';
					$sql = "select * from admin where admin_id='$admin_id'";
					$result = $con->query($sql);
					while ($row = $result->fetch_assoc()) {
					?>
						<li><a href="#"><i class="fas fa-user"> </i> <?= $row['admin_name'] ?></a>
						</li>

					<?php
					}

					?>

				</div>

			</ul>
		</div>

		<div class="content">
			<div class="themhh">
				<form action="phpthemhh.php" id="f-themhh" enctype="multipart/form-data" method="POST">
					<div class="f-thembtn">
						<div class="content-f">THÊM HÀNG HÓA</div>
						<hr>
						<div class="f-item">
							<table>
								<tr>
							<td>Tên hàng hóa</td>
							<td><input type="text" name="product_name" class="inputt"></td>
						</tr>
						<tr>
							<td>Thương hiệu</td>
							<td><select name="product_brand" class="inputt">
								<option value="">--</option>
								<option value="Apple">Apple</option>
								<option value="Samsung">Samsung</option>
								<option value="JBL">JBL</option>
								<option value="Sony">Sony</option>
								<option value="LG">LG</option>
								<option value="Xiaomi">Xiaomi</option>
								<option value="Huawei">Huawei</option>
								<option value="Beats">Beats</option>
								<option value="Harman/kardon">Harman/kardon</option>
								<option value="Logitech">Logitech</option>
								<option value="Oppo">Oppo</option>
								<option value="Mozard">Mozard</option>
							</select></td>
						</tr>
							<tr><td>Giá</td>
							<td><input type="text" name="product_price" class="inputt"></td></tr>
							<tr><td>Loại</td>
							<td><select name="product_type" class="inputt">
								<option value="">--</option>
								<option value="Có dây">Có dây</option>
								<option value="Không dây">Không dây</option>
								<option value="Loa">Loa</option>
							</select></td></tr>
							
							<tr><td>Pin</td>
							<td><input type="text" name="pin" class="inputt"></td></tr>
							<tr><td>Cổng sạc</td>
							<td><input type="text" name="congsac" class="inputt"></td></tr>
							<tr><td>Công nghệ âm thanh</td>
							<td><input type="text" name="congngheamthanh" class="inputt"></td></tr>
							<tr><td>Tương thích</td>
							<td><input type="text" name="tuongthich" class="inputt"></td></tr>
							<tr><td>Hỗ trợ kết nối</td>
							<td><input type="text" name="hotroketnoi" class="inputt"></td></tr>
							<tr><td>Tiện ích</td>
							<td><input type="text" name="tienich" class="inputt"></td></tr>
							<tr><td>Điều khiển</td>
							<td><input type="text" name="dieukhien" class="inputt"></td></tr>
							<tr><td>Chi tiết</td>
							<td><textarea name="chitiet" rows="9" cols="45" class="inputt"> </textarea>
								</td></tr>							



							<tr><td>Hình ảnh</td>
							<td><input type="file" name="product_image1">

							<input type="file" name="product_image2">
							<br>
							<input type="file" name="product_image3">

							<input type="file" name="product_image4">
							</td></tr>
							</table>
						</div>


					</div>
					<div class="f-btn">
						<input type="submit" name="" value="Thêm" id="them">

						<input type="reset" name="" value="Hủy" id="huy">
					</div>

				</form>
			</div>
		</div>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?>
</body>

</html>