<?php
require 'connection.php';
$product_name=$_POST['product_name'];

$pin=$_POST['pin'];
$congsac=$_POST['congsac'];
$congngheamthanh=$_POST['congngheamthanh'];
$tuongthich=$_POST['tuongthich'];
$hotroketnoi=$_POST['hotroketnoi'];
$tienich=$_POST['tienich'];
$dieukhien=$_POST['dieukhien'];
$chitiet=$_POST['chitiet'];
$product_brand=$_POST['product_brand'];
$product_price=$_POST['product_price'];
$product_type=$_POST['product_type'];
$product_option=$_POST['product_option'];
$image1="../image/".$_FILES['product_image1']['name'];
$image2="../image/".$_FILES['product_image2']['name'];
$image3="../image/".$_FILES['product_image3']['name'];
$image4="../image/".$_FILES['product_image4']['name'];
$sql="INSERT INTO `product`( `product_name`, `product_brand`, `giagiam`,`product_price`, `product_type`, `product_option`, `product_image`, `product_image1`, `product_image2`, `product_image3`,`pin`,`congsac`,`congngheamthanh`,`tuongthich`,`hotroketnoi`,`tienich`,`dieukhien`,`chitiet`) VALUES ('$product_name','$product_brand','$product_price','$product_price','$product_type','$product_option','$image1','$image2','$image3','$image4','$pin','$congsac','$congngheamthanh','$tuongthich','$hotroketnoi','$tienich','$dieukhien','$chitiet')";
move_uploaded_file($_FILES['product_image1']['tmp_name'], $image1);
move_uploaded_file($_FILES['product_image2']['tmp_name'], $image2);
move_uploaded_file($_FILES['product_image3']['tmp_name'], $image3);
move_uploaded_file($_FILES['product_image4']['tmp_name'], $image4);
$result=$con->query($sql);


header("location: index.php");
$con->close();
?>