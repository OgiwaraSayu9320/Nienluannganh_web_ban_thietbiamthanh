<?php
$con =new mysqli("localhost", "root", "","shop");
$con->set_charset("utf8");
?>