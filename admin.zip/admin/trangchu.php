<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Thêm Hàng Hóa</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body class="body">
<!-- <img src="logo/Since_2022-removebg-preview.png" alt="logo" class="logo">
	<?php
	session_start();
	$admin_id = $_SESSION['admin_id'];

	if (isset($_SESSION['admin_id'])) {

	?>
		<div class="menu">
			<hr>
			<ul>
				 <li>
					<a href="index.php">Trang chủ</a>
				</li> 


				<li>
					<a href="danhsach.php">Danh sách sản phẩm</a>
				</li>
				<li>
					<a href="themhanghoa.php">Thêm hàng hóa</a>
				</li>

				<li>
					<a href="nhaphang.php">Nhập hàng vào kho</a>
				</li>

				<li>
					<a href="dshoadon.php">Danh sách hóa đơn</a>
				</li>

				<li>
					<a href="doanhthu.php">Doanh thu</a>
				</li>

				<li>
					<a href="dskhachhang.php">Danh sách khách hàng</a>
				</li>

				<li>
					<a href="logoutadmin.php">Đăng xuất</a>
				</li>

				<?php
				require 'connection.php';
				$sql = "select * from admin where admin_id='$admin_id'";
				$result = $con->query($sql);
				while ($row = $result->fetch_assoc()) {
				?>
					<li><a href="#"><?= $row['admin_name'] ?></a>
					</li>

				<?php
				}
				$con->close();

				?>

			</ul>
		</div>
		<div class="content">


		</div>
	<?php
	} else {
		header("location:loginadmin.html");
	};
	?> -->
</body>

</html>