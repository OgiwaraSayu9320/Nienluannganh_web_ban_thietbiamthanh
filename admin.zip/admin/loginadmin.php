<?php
session_start();
$admin_email=$_POST['admin_email'];
$admin_password=$_POST['admin_password'];
$pass=md5($admin_password);
require 'connection.php';
$sql="select * from admin where admin_email='$admin_email' and admin_password='$pass'";
$result=$con->query($sql);
$row = $result->fetch_assoc();

$_SESSION['admin_id'] = $row['admin_id'];

if ($result->num_rows > 0) {
	header("Location:index.php");

} else { header("Location:loginadmin.html") ;}

$con->close();
?>
